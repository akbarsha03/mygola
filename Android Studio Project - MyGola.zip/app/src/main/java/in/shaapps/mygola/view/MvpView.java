package in.shaapps.mygola.view;

import android.content.Context;

public interface MvpView {

    Context getContext();
}
